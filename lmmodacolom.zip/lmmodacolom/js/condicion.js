// JavaScript Document
let calificaion = 85;
let mensaje;
if (calificacion >= 60 ) {
   mensaje ="Aprobado";
} else {
	mensaje ="Reprobado";
}
document.getElementById("notas").innerText = "mensaje";